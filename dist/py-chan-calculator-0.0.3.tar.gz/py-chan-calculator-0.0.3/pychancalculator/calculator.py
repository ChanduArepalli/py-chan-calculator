class Calculator:

    def add(self, num1, num2):
        return num1 + num2

    def dif(self, num1, num2):
        return num1 - num2

    def div(self, num1, num2):
        return num1 / num2

    def mod(self, num1, num2):
        return num1 % num2

    def multi(self, num1, num2):
        return num1 * num2

