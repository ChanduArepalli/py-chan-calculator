"""
pychancalculator.

chandumanikumar4@gmail.com.
"""

__version__ = "0.0.1"
__author__ = 'Chandu Arepalli'
__credits__ = ''