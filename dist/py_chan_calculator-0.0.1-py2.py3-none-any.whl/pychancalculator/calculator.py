class Calculator:

    def add(self, num1, num2):
        return num1 + num2

    def difference(self, num1, num2):
        return num1 - num2

    def divide(self, num1, num2):
        return num1 / num2

    def mod(self, num1, num2):
        return num1 % num2

    def multi(self, num1, num2):
        return num1 * num2

